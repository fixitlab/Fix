/* FIX — FINAL SUPABASE AUTH STAGE */
const SUPABASE_URL = 'https://mlkkkbzpwxhuhbigzgqb.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_0wTMiTdyI-l9XR5F2Nwwug_703_jGyZ';

if (!window.supabase || typeof window.supabase.createClient !== 'function') {
  alert('FIX could not load the Supabase connection library. Connect the laptop to the internet and start FIX with START_FIX_IT.bat.');
  throw new Error('Supabase browser library was not loaded.');
}

const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
});
const AUTH_REDIRECT_URL = new URL('verify.html', window.location.href).href;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
// FIX day/night theme preference (saved locally on this device).
function applyTheme(){
  const night=localStorage.getItem('fixTheme')==='night';
  document.body.classList.toggle('night-mode',night);
  document.documentElement.dataset.theme=night?'night':'day';
}
function toggleTheme(){
  const next=document.body.classList.contains('night-mode')?'day':'night';
  localStorage.setItem('fixTheme',next);
  applyTheme();
function openAuth(mode='signup'){
  const landing=document.getElementById('landing'),auth=document.getElementById('auth');
  if(landing)landing.hidden=true;if(auth)auth.hidden=false;
  if(mode==='login')document.getElementById('loginTab')?.click();else document.getElementById('signupTab')?.click();
  window.scrollTo(0,0);
}
function closeAuth(){const auth=document.getElementById('auth'),landing=document.getElementById('landing');if(auth)auth.hidden=true;if(landing)landing.hidden=false;window.scrollTo(0,0);}
  const main=$('#main');
  if(main && !$('#auth').hidden) return;
  if(main && main.innerHTML && main.querySelector('.settings')) main.innerHTML=settings();
}
applyTheme();
let state=JSON.parse(localStorage.getItem('fixitFinal')||'null')||{accounts:[],user:null,verified:false,balance:0,posts:[],likes:{},comments:{},messages:[],following:[],connections:0,unread:0};
state.accounts=Array.isArray(state.accounts)?state.accounts:[];state.messages=Array.isArray(state.messages)?state.messages:[];state.posts=Array.isArray(state.posts)?state.posts:[];
const save=()=>localStorage.setItem('fixitFinal',JSON.stringify(state));
const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const initials=n=>(n||'U').split(/\s+/).map(x=>x[0]).slice(0,2).join('').toUpperCase();

let authRecoveryInProgress = false;
let activeLikesTable = 'likes';
let realtimeChannel = null;
async function ensureFreshSession(){
  const {data, error} = await supabaseClient.auth.getSession();
  if(error) throw error;
  let session = data?.session;
  if(!session) throw new Error('Your session has ended. Please log in again.');
  const expiresAt = Number(session.expires_at || 0);
  if(expiresAt && expiresAt <= Math.floor(Date.now()/1000) + 60){
    const refreshed = await supabaseClient.auth.refreshSession();
    if(refreshed.error || !refreshed.data?.session){
      await supabaseClient.auth.signOut({scope:'local'});
      throw new Error('Your session has expired. Please log in again.');
    }
    session = refreshed.data.session;
  }
  return session;
}
function isJwtError(error){
  const m = String(error?.message || error || '').toLowerCase();
  return m.includes('jwt expired') || m.includes('exp claim') || m.includes('invalid jwt') || m.includes('token is expired');
}
async function recoverFromAuthError(error){
  if(!isJwtError(error) || authRecoveryInProgress) return false;
  authRecoveryInProgress = true;
  try{
    const refreshed = await supabaseClient.auth.refreshSession();
    if(!refreshed.error && refreshed.data?.session) return true;
    await supabaseClient.auth.signOut({scope:'local'});
    state.user = null; state.verified = false; save();
    alert('Your FIX session has expired. Please log in again.');
    location.reload();
  } finally { authRecoveryInProgress = false; }
  return false;
}
function friendlySupabaseError(error){
  if(!navigator.onLine)return'Your laptop is offline. Connect to the internet and try again.';
  if(!error)return'The request could not be completed.';
  const msg=error.message||String(error);
  if(/failed to fetch/i.test(msg))return'FIX could not reach Supabase. Make sure the laptop is connected to the internet and FIX was started with START_FIX_IT.bat.';
  if(/jwt expired|exp claim|invalid jwt|token is expired/i.test(msg))return'Your FIX login session has expired. Please log in again.';
  return msg;
}
function badges(){
  const unread=Number(state.unread||0);
  const msgBadge=$('#msgBadge'), navBadge=$('#navBadge');
  [msgBadge,navBadge].forEach(b=>{ if(b){ b.textContent=''; b.hidden=unread<=0; b.setAttribute('aria-label', unread?`${unread} unread notification${unread===1?'':'s'}`:''); } });
}
function openApp(){$('#landing').hidden=true;$('#auth').hidden=true;$('#app').hidden=false;badges();render('home');loadRemotePosts().then(()=>render('home'))}

async function loadRemotePosts(){
  try{
    await ensureFreshSession();
    const {data,error}=await supabaseClient.from('posts').select('*').order('created_at',{ascending:false});
    if(error)throw error;
    const raw=data||[];
    const ids=[...new Set(raw.map(p=>p.user_id).filter(Boolean))];
    let profilesById={};
    if(ids.length){
      const rr=await supabaseClient.from('profiles').select('*').in('id',ids);
      if(rr.error)throw rr.error;
      (rr.data||[]).forEach(x=>profilesById[x.id]=normalizeProfileRow(x));
    }
    state.posts=raw.map(p=>{
      const u=profilesById[p.user_id]||{};
      return {
        id:p.id,
        user_id:p.user_id,
        name:u.name||'FIX member',
        location:u.location||p.location||'',
        text:p.text??p.content??p.body??'',
        media:p.media_url||p.image_url||p.video_url||p.media||'',
        mediaType:p.media_type||(p.video_url?'video':p.image_url?'image':''),
        photo:u.photo||''
      };
    });
    state.likes={};
    state.comments={};
    state.commentLikes={};
    if(state.posts.length){
      const pids=state.posts.map(p=>p.id);
      const [ls,cs]=await Promise.all([
        readLikes(pids),
        supabaseClient.from('comments').select('*').in('post_id',pids).order('created_at',{ascending:true})
      ]);
      if(cs.error)throw cs.error;
      (ls||[]).forEach(x=>state.likes[x.post_id]=(state.likes[x.post_id]||0)+1);
      const comments=cs.data||[];
      const cids=[...new Set(comments.map(x=>x.user_id).filter(Boolean))];
      let cp={};
      if(cids.length){
        const rr=await supabaseClient.from('profiles').select('*').in('id',cids);
        if(!rr.error)(rr.data||[]).forEach(x=>cp[x.id]=normalizeProfileRow(x));
      }
      comments.forEach(x=>(state.comments[x.post_id]??=[]).push({
        id:x.id,
        user_id:x.user_id,
        name:cp[x.user_id]?.name||x.user_name||'FIX member',
        text:x.text??x.content??'',
        likes:0
      }));
    }
    save();
  }catch(e){console.warn('Posts load:',e);}
}
async function saveRemotePost(post){
  await ensureFreshSession();
  const base={user_id:state.user.id,media_url:post.media||null,media_type:post.mediaType||null};
  let result=await supabaseClient.from('posts').insert({...base,content:post.text||''}).select().single();
  if(result.error && /content.*column|column.*content|schema cache/i.test(result.error.message||'')){
    result=await supabaseClient.from('posts').insert({...base,text:post.text||''}).select().single();
  }
  if(result.error)throw result.error;
  return result.data;
}
async function likePost(id){
  try{
    await ensureFreshSession();
    const table=activeLikesTable;
    let existing=await supabaseClient.from(table).select('post_id').eq('post_id',id).eq('user_id',state.user.id).maybeSingle();
    if(existing.error && table==='likes'){
      const fallback=await supabaseClient.from('post_likes').select('post_id').eq('post_id',id).eq('user_id',state.user.id).maybeSingle();
      if(!fallback.error){activeLikesTable='post_likes';existing=fallback;}
    }
    if(existing.error)throw existing.error;
    if(existing.data){
      const {error}=await supabaseClient.from(activeLikesTable).delete().eq('post_id',id).eq('user_id',state.user.id);if(error)throw error;
      state.likes[id]=Math.max(0,(state.likes[id]||1)-1);
    }else{
      const {error}=await supabaseClient.from(activeLikesTable).insert({post_id:id,user_id:state.user.id});if(error)throw error;
      state.likes[id]=(state.likes[id]||0)+1;
    }
    save();render('home');
  }catch(e){alert(friendlySupabaseError(e));}
}

async function commentPost(id){
  const t=prompt('Write a comment');if(!t?.trim())return;
  try{
    await ensureFreshSession();
    const {error}=await supabaseClient.from('comments').insert({post_id:id,user_id:state.user.id,text:t.trim()});
    if(error)throw error;
    (state.comments[id]??=[]).push({name:state.user.name,text:t.trim()});save();render('home');
  }catch(e){alert(friendlySupabaseError(e));}
}

async function choosePhoto(type){
  try{await ensureFreshSession();}catch(e){alert(friendlySupabaseError(e));return;}
  const i=document.createElement('input');i.type='file';i.accept='image/*';
  i.onchange=async()=>{const f=i.files[0];if(!f)return;try{
    const url=await uploadToBucket('profile_media',f,state.user.id);
    const field=type==='cover'?'cover_url':'avatar_url';
    const {error}=await supabaseClient.from('profiles').upsert({id:state.user.id,[field]:url},{onConflict:'id'});if(error)throw error;
    state.user[type==='cover'?'cover':'photo']=url;save();render('profile');
  }catch(e){alert(friendlySupabaseError(e));}};
  i.click();
}

function searchFilterValue(v){return String(v||'').replace(/[(),]/g,' ').replace(/[%*]/g,' ').trim().slice(0,80);}
async function doSearch(){
  const q=searchFilterValue($('#skillQ')?.value),loc=searchFilterValue($('#locQ')?.value),results=$('#results');
  if(!results)return;
  results.className='empty';results.textContent='Searching…';
  try{
    await ensureFreshSession();
    let query=supabaseClient.from('profiles').select('*').neq('id',state.user.id);
    if(q)query=query.or(`skill.ilike.%${q}%,full_name.ilike.%${q}%`);
    if(loc)query=query.ilike('location',`%${loc}%`);
    const {data,error}=await query.limit(50);if(error)throw error;
    results.className='';
    results.innerHTML=(data||[]).map(x=>`<div class="result"><span class="avatar">${initials(x.full_name)}</span><div><b>${esc(x.full_name||'FIX member')}</b><div>${esc(x.skill||'')}</div><small>${esc(x.location||'')}</small></div><button onclick='viewOther(${JSON.stringify({id:x.id,name:x.full_name||'FIX member',skill:x.skill||'',location:x.location||'',photo:x.avatar_url||'',cover:x.cover_url||'',bio:x.bio||'',followers:x.followers_count||0,connections:x.connections_count||0})})'>Profile</button></div>`).join('')||'<div class="empty">No matching profiles found.</div>';
  }catch(e){results.className='empty';results.textContent=friendlySupabaseError(e);}
}


/* FIX FINAL CONNECTION REPAIR: cross-account profiles, public posts, comments and messaging. */
function normalizeProfileRow(x){return {id:x.id,name:x.full_name||x.name||x.username||'FIX member',skill:x.skill||x.service||'',location:x.location||'',photo:x.avatar_url||x.photo_url||'',cover:x.cover_url||'',bio:x.bio||'',followers:x.followers_count||0,connections:x.connections_count||0,is_verified:!!(x.is_verified||x.verified||x.verification_badge),following:0};}

async function loadRemotePosts(){
  try{
    await ensureFreshSession();
    const pr=await supabaseClient.from('posts').select('*').order('created_at',{ascending:false});
    if(pr.error) throw pr.error;
    const raw=pr.data||[];
    const userIds=[...new Set(raw.map(p=>p.user_id).filter(Boolean))];
    let profilesById={};
    if(userIds.length){
      const rr=await supabaseClient.from('profiles').select('*').in('id',userIds);
      if(!rr.error)(rr.data||[]).forEach(x=>profilesById[x.id]=normalizeProfileRow(x));
    }
    state.posts=raw.map(p=>{
      const u=profilesById[p.user_id]||{};
      return {id:p.id,user_id:p.user_id,name:u.name||'FIX member',location:u.location||'',text:p.text??p.content??p.body??'',media:p.media_url||p.media||'',mediaType:p.media_type||'',photo:u.photo||''};
    });
    const ids=state.posts.map(p=>p.id); state.likes={}; state.comments={};
    if(ids.length){
      const [ls,cs]=await Promise.all([readLikes(ids),supabaseClient.from('comments').select('*').in('post_id',ids).order('created_at')]);
      if(cs.error) throw cs.error;
      ls.forEach(x=>state.likes[x.post_id]=(state.likes[x.post_id]||0)+1);
      const cids=[...new Set((cs.data||[]).map(x=>x.user_id).filter(Boolean))]; let cp={};
      if(cids.length){const rr=await supabaseClient.from('profiles').select('*').in('id',cids);if(!rr.error)(rr.data||[]).forEach(x=>cp[x.id]=normalizeProfileRow(x));}
      (cs.data||[]).forEach(x=>(state.comments[x.post_id]??=[]).push({id:x.id,user_id:x.user_id,name:cp[x.user_id]?.name||x.user_name||'FIX member',text:x.text??x.content??''}));
    }
    save();
  }catch(e){console.warn('Posts load:',e);}
}

async function loadPostsForUser(userId){
  try{
    const {data,error}=await supabaseClient.from('posts').select('*').eq('user_id',userId).order('created_at',{ascending:false});
    if(error) throw error;
    const profilePosts=(data||[]).map(p=>({id:p.id,user_id:p.user_id,name:'',location:'',text:p.text??p.content??p.body??'',media:p.media_url||p.media||'',mediaType:p.media_type||'',photo:''}));
    return profilePosts;
  }catch(e){console.warn('Profile posts:',e);return [];}
}

function profile(u,other){
  const posts=state.posts.filter(p=>p.user_id&&u.id&&p.user_id===u.id);
  const shownPosts=posts.length?posts:[];
  return `<div class="profile"><div class="cover">${u.cover?`<img src="${esc(u.cover)}">`:''}</div><div class="profilePhoto">${u.photo?`<img src="${esc(u.photo)}">`:initials(u.name)}</div><h2>${esc(u.name)}</h2><b>${esc(u.skill||'FIX member')}</b><p>${esc(u.bio||'')}</p><p class="muted">📍 ${esc(u.location||'')}</p><div class="stats"><span><b>${u.posts||shownPosts.length||0}</b>Posts</span><span><b>${u.followers||0}</b>Followers</span><span><b>${u.connections||0}</b>Connections</span></div>${other?`<div class="profileActions"><button onclick="openThread('${esc(u.id)}','${esc(u.name)}')">Message</button><button class="soft" onclick="followUser('${esc(u.id)}','${esc(u.name)}')">${u.isFollowing?'Following · Unfollow':'Follow'}</button><button class="soft" onclick="connectUser('${esc(u.name)}')">Connect</button></div>`:`<div class="toolRow"><button onclick="editProfile()">Edit Profile</button><button onclick="choosePhoto('photo')">Profile Photo</button><button onclick="choosePhoto('cover')">Cover Photo</button><button onclick="render('settings')">Settings</button></div>`}<hr><h3>Posts</h3>${shownPosts.length?shownPosts.map(postHTML).join(''):'<div class="empty">No public posts yet.</div>'}</div>`;
}

async function viewOther(u){
  const normalized={...u};
  $('#main').innerHTML='<div class="empty">Loading profile…</div>';
  try{
    const posts=await loadPostsForUser(u.id);
    if(posts.length){posts.forEach(p=>{p.name=u.name;p.location=u.location;p.photo=u.photo;}); state.posts=state.posts.filter(p=>p.user_id!==u.id).concat(posts);}
  }catch(e){console.warn(e)}
  $('#main').innerHTML=profile(normalized,true);window.scrollTo(0,0);
}

async function doSearch(){
  const q=searchFilterValue($('#skillQ')?.value),loc=searchFilterValue($('#locQ')?.value),results=$('#results');
  if(!results)return;
  if(!q&&!loc){results.className='empty';results.textContent='Enter a name, skill, or location to search.';return;}
  results.className='empty';results.textContent='Searching…';
  try{
    await ensureFreshSession();
    let data=null,error=null;
    // Query all likely public profile columns. The SQL policy supplied with this build makes profiles readable.
    let query=supabaseClient.from('profiles').select('*').neq('id',state.user.id);
    if(q) query=query.or(`full_name.ilike.%${q}%,skill.ilike.%${q}%,location.ilike.%${q}%`);
    if(loc) query=query.ilike('location',`%${loc}%`);
    ({data,error}=await query.limit(50));
    // If an older schema does not expose one of the optional columns, retry with the name column only.
    if(error){
      let fallback=supabaseClient.from('profiles').select('*').neq('id',state.user.id);
      if(q) fallback=fallback.ilike('full_name',`%${q}%`);
      if(loc) fallback=fallback.ilike('location',`%${loc}%`);
      ({data,error}=await fallback.limit(50));
    }
    if(error)throw error;
    const rows=(data||[]).map(normalizeProfileRow);
    results.className='';
    results.innerHTML=rows.map(x=>`<div class="result"><span class="avatar">${x.photo?`<img src="${esc(x.photo)}">`:initials(x.name)}</span><div><b>${esc(x.name)}</b><div>${esc(x.skill)}</div><small>${esc(x.location)}</small></div><button onclick='viewOther(${JSON.stringify(x).replace(/</g,'\\u003c')})'>Profile</button></div>`).join('')||'<div class="empty">No matching profiles found. Check the spelling or try a skill/location.</div>';
  }catch(e){results.className='empty';results.textContent=friendlySupabaseError(e);console.warn('Search:',e);}
}

let activeThreadUserId=null, activeThreadName='';
async function loadThreads(){
  try{
    await ensureFreshSession();
    const {data,error}=await supabaseClient.from('messages').select('*').or(`sender_id.eq.${state.user.id},recipient_id.eq.${state.user.id}`).order('created_at',{ascending:true});
    if(error)throw error;
    const ids=[...new Set((data||[]).map(m=>m.sender_id===state.user.id?m.recipient_id:m.sender_id).filter(Boolean))];
    let pm={}; if(ids.length){const rr=await supabaseClient.from('profiles').select('*').in('id',ids);if(!rr.error)(rr.data||[]).forEach(x=>pm[x.id]=normalizeProfileRow(x));}
    const groups={};(data||[]).forEach(m=>{const other=m.sender_id===state.user.id?m.recipient_id:m.sender_id;if(!groups[other])groups[other]={id:other,name:pm[other]?.name||'FIX member',items:[]};groups[other].items.push({id:m.id,text:m.text||m.body||'',mine:m.sender_id===state.user.id});});
    return Object.values(groups);
  }catch(e){console.warn('Messages load:',e);return [];}
}
function messages(){
  const boxId='messageList'; setTimeout(async()=>{const box=$('#'+boxId);if(!box)return;const ts=await loadThreads();box.innerHTML=ts.length?ts.map(t=>`<div class="result" onclick="openThread('${esc(t.id)}','${esc(t.name)}')"><span class="avatar">${initials(t.name)}</span><div><b>${esc(t.name)}</b><div class="muted">${esc(t.items.at(-1)?.text||'Start a conversation')}</div></div></div>`).join(''):'<div class="empty">No messages yet. Open a profile and tap Message.</div>';},0);
  return `<div class="settings"><h2>Messages</h2><div id="${boxId}" class="empty">Loading messages…</div></div>`;
}
async function openThread(userId,name){
  activeThreadUserId=userId;activeThreadName=name||'FIX member';
  $('#modalBody').innerHTML=`<h2>Messages</h2><b>${esc(activeThreadName)}</b><div id="threadBody" class="thread">Loading…</div><div class="messageComposer"><textarea id="reply" rows="2" placeholder="Type a message..."></textarea><button onclick="sendMessage()">Send</button></div>`;$('#modal').hidden=false;
  try{await ensureFreshSession();const {data,error}=await supabaseClient.from('messages').select('*').or(`and(sender_id.eq.${state.user.id},recipient_id.eq.${userId}),and(sender_id.eq.${userId},recipient_id.eq.${state.user.id})`).order('created_at',{ascending:true});if(error)throw error;$('#threadBody').innerHTML=(data||[]).map(m=>`<div class="bubble ${m.sender_id===state.user.id?'mine':''}">${esc(m.text||m.body||'')}</div>`).join('')||'<p class="muted">Start the conversation.</p>';}catch(e){$('#threadBody').textContent=friendlySupabaseError(e);}
}
async function sendMessage(){
  const text=$('#reply')?.value.trim();if(!text||!activeThreadUserId)return;
  try{await ensureFreshSession();const {error}=await supabaseClient.from('messages').insert({sender_id:state.user.id,recipient_id:activeThreadUserId,text});if(error)throw error;await openThread(activeThreadUserId,activeThreadName);}catch(e){alert(friendlySupabaseError(e));}
}

/* ================= FIX FINAL CONNECTION BUILD =================
   Cross-account profiles, public posts, comments, likes, messages and notifications.
   This block intentionally overrides older demo functions above so there is one
   final implementation without requiring a redesign. */

function normalizeProfileRow(x){
  return {
    id:x.id,
    name:x.full_name||x.name||x.username||'FIX member',
    skill:x.skill||x.service||'',
    location:x.location||'',
    photo:x.avatar_url||x.profile_photo||x.photo_url||'',
    cover:x.cover_url||x.cover_photo||'',
    bio:x.bio||'',
    followers:Number(x.followers_count||0),
    connections:Number(x.connections_count||0),
    following:0,
    is_verified:!!(x.is_verified||x.verified||x.verification_badge)
  };
}

async function loadSupabaseUser(){
  const {data,error}=await supabaseClient.auth.getUser();
  if(error||!data?.user)return false;
  const au=data.user;
  const meta=au.user_metadata||{};
  let profile=null;
  const pr=await supabaseClient.from('profiles').select('*').eq('id',au.id).maybeSingle();
  if(pr.error && !/0 rows|multiple/i.test(pr.error.message||'')) throw pr.error;
  profile=pr.data||null;
  // Ensure every authenticated account has a searchable public profile row.
  const basic={id:au.id,full_name:profile?.full_name||meta.full_name||'FIX member',skill:profile?.skill||meta.skill||'',location:profile?.location||meta.location||'',bio:profile?.bio||''};
  if(!profile){
    const ins=await supabaseClient.from('profiles').upsert(basic,{onConflict:'id'});
    if(ins.error) throw ins.error;
    profile=basic;
  }
  state.user={id:au.id,email:au.email||'',name:profile.full_name||meta.full_name||'FIX member',skill:profile.skill||meta.skill||'',location:profile.location||meta.location||'',photo:profile.avatar_url||'',cover:profile.cover_url||'',followers:Number(profile.followers_count||0),connections:Number(profile.connections_count||0),following:0,is_verified:!!(profile.is_verified||profile.verified||profile.verification_badge),bio:profile.bio||''};
  state.verified=!!au.email_confirmed_at; save(); return true;
}

async function readLikes(ids){
  if(!ids.length)return [];
  let r=await supabaseClient.from(activeLikesTable).select('post_id,user_id').in('post_id',ids);
  if(r.error && activeLikesTable==='post_likes'){
    const f=await supabaseClient.from('likes').select('post_id,user_id').in('post_id',ids);
    if(!f.error){activeLikesTable='likes';r=f;}
  }
  if(r.error)throw r.error; return r.data||[];
}

async function loadRemotePosts(){
  try{
    await ensureFreshSession();
    const {data,error}=await supabaseClient.from('posts').select('*').order('created_at',{ascending:false});
    if(error)throw error;
    const raw=data||[], ids=[...new Set(raw.map(p=>p.user_id).filter(Boolean))]; let profilesById={};
    if(ids.length){const rr=await supabaseClient.from('profiles').select('*').in('id',ids);if(rr.error)throw rr.error;(rr.data||[]).forEach(x=>profilesById[x.id]=normalizeProfileRow(x));}
    state.posts=raw.map(p=>{const u=profilesById[p.user_id]||{};return {id:p.id,user_id:p.user_id,name:u.name||'FIX member',location:u.location||'',text:p.text??p.content??p.body??'',media:p.media_url||p.media||'',mediaType:p.media_type||'',photo:u.photo||''};});
    state.likes={}; state.comments={}; state.commentLikes={};
    if(state.posts.length){
      const pids=state.posts.map(p=>p.id);
      const [ls,cs]=await Promise.all([readLikes(pids),supabaseClient.from('comments').select('*').in('post_id',pids).order('created_at',{ascending:true})]);
      if(cs.error)throw cs.error;
      (ls||[]).forEach(x=>state.likes[x.post_id]=(state.likes[x.post_id]||0)+1);
      const comments=cs.data||[], cids=[...new Set(comments.map(x=>x.user_id).filter(Boolean))]; let cp={};
      if(cids.length){const rr=await supabaseClient.from('profiles').select('*').in('id',cids);if(!rr.error)(rr.data||[]).forEach(x=>cp[x.id]=normalizeProfileRow(x));}
      comments.forEach(x=>(state.comments[x.post_id]??=[]).push({id:x.id,user_id:x.user_id,profile:cp[x.user_id]||null,name:cp[x.user_id]?.name||x.user_name||'FIX member',text:x.text??x.content??'',likes:0}));
      const commentIds=comments.map(x=>x.id);
      if(commentIds.length){const cr=await supabaseClient.from('comment_likes').select('comment_id,user_id').in('comment_id',commentIds);if(!cr.error)(cr.data||[]).forEach(x=>state.commentLikes[x.comment_id]=(state.commentLikes[x.comment_id]||0)+1);}
    }
    save();
  }catch(e){console.warn('Posts load:',e);}
}

async function saveRemotePost(post){
  await ensureFreshSession();
  let result=await supabaseClient.from('posts').insert({user_id:state.user.id,text:post.text||'',media_url:post.media||null,media_type:post.mediaType||null}).select().single();
  if(result.error && /text.*column|column.*text|schema cache/i.test(result.error.message||'')) result=await supabaseClient.from('posts').insert({user_id:state.user.id,content:post.text||'',media_url:post.media||null,media_type:post.mediaType||null}).select().single();
  if(result.error)throw result.error;
  post.id=result.data?.id||post.id; return true;
}

async function publish(){
  try{
    await ensureFreshSession(); const text=$('#postText').value.trim(), f=$('#mediaInput').files[0];
    if(!text&&!f){alert('Write something or choose a photo/video.');return;}
    let media='',mediaType=''; if(f){media=await uploadToBucket('post_media',f,state.user.id);mediaType=f.type.startsWith('video/')?'video':'image';}
    const post={name:state.user.name,location:state.user.location,text,media,mediaType,photo:state.user.photo};
    await saveRemotePost(post); state.posts.unshift({...post,id:post.id,user_id:state.user.id}); save(); $('#modal').hidden=true; render('home');
  }catch(e){alert(friendlySupabaseError(e));}
}

async function likePost(id){
  try{
    await ensureFreshSession();
    const existing=await supabaseClient.from('likes').select('id').eq('post_id',id).eq('user_id',state.user.id).maybeSingle();
    if(existing.error)throw existing.error;
    if(existing.data){
      const r=await supabaseClient.from('likes').delete().eq('post_id',id).eq('user_id',state.user.id);
      if(r.error)throw r.error;
    }else{
      const r=await supabaseClient.from('likes').insert({post_id:id,user_id:state.user.id});
      if(r.error)throw r.error;
    }
    await loadRemotePosts();
    render('home');
  }catch(e){alert(friendlySupabaseError(e));}
}
async function commentPost(id){
  const t=prompt('Write a comment');
  if(!t?.trim())return;
  try{
    await ensureFreshSession();
    const {error}=await supabaseClient.from('comments').insert({
      post_id:id,
      user_id:state.user.id,
      content:t.trim()
    });
    if(error)throw error;
    await loadRemotePosts();
    render('home');
  }catch(e){alert(friendlySupabaseError(e));}
}
async function likeComment(commentId,postId){
  // Comment likes are not part of the live database schema yet.
  // Keep the button harmless until that feature is added.
  alert('Comment likes are coming in the next backend phase.');
}
function postHTML(p){
  const likes=state.likes[p.id]||0, cs=state.comments[p.id]||[];
  const owner={id:p.user_id,name:p.name,skill:'',location:p.location,photo:p.photo,cover:'',bio:''};
  return `<article class="post"><div class="postHead" onclick='viewOther(${JSON.stringify(owner).replace(/</g,'\\u003c')})' style="cursor:pointer"><span class="avatar">${p.photo?`<img src="${esc(p.photo)}">`:initials(p.name)}</span><div><b>${esc(p.name)}</b><div class="muted">${esc(p.location)}</div></div></div><p>${esc(p.text)}</p>${p.media?(p.mediaType==='video'?`<video controls src="${esc(p.media)}"></video>`:`<img src="${esc(p.media)}">`):''}<div class="postActions"><button class="soft" onclick="likePost('${p.id}')">♡ ${likes}</button><button class="soft" onclick="commentPost('${p.id}')">💬 ${cs.length} Comments</button><button class="soft">↗ Share</button></div>${cs.slice(-8).map(c=>`<div class="comment"><span class="commentIdentity" role="button" tabindex="0" onclick="openProfileById('${esc(c.user_id||'')}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openProfileById('${esc(c.user_id||'')}')}"><b>${esc(c.name)}</b></span> ${esc(c.text)} <button class="soft commentLike" onclick="likeComment('${c.id}','${p.id}')">♡ ${state.commentLikes?.[c.id]||0}</button></div>`).join('')}</article>`;
}

function search(){setTimeout(()=>attachLocationAutocomplete('locQ','locQSuggestions'),0);return `<div class="searchBox"><h2>Search for skill or username</h2><input id="skillQ" placeholder="Skill or username" autocomplete="off"><input id="locQ" placeholder="Start typing a location" autocomplete="off"><div id="locQSuggestions" class="locationSuggestions" hidden></div><button onclick="doSearch()" style="background:#e00000;color:#fff;width:100%;padding:12px">Search</button></div><div id="results" class="empty">Search by name, skill, or location.</div>`;}
function searchFilterValue(v){return String(v||'').trim().slice(0,80);}
async function doSearch(){
  const q=searchFilterValue($('#skillQ')?.value),loc=searchFilterValue($('#locQ')?.value),results=$('#results');
  if(!results)return;
  if(!q&&!loc){results.className='empty';results.textContent='Enter a name, skill, or location to search.';return;}
  results.className='empty';results.textContent='Searching…';
  try{
    await ensureFreshSession();
    let query=supabaseClient.from('profiles').select('*').neq('id',state.user.id);
    if(q){
      // Live FIX schema stores the display name in `name`.
      query=query.or(`name.ilike.%${q}%,full_name.ilike.%${q}%,skill.ilike.%${q}%,location.ilike.%${q}%`);
    }
    if(loc)query=query.ilike('location',`%${loc}%`);
    let {data,error}=await query.limit(50);
    if(error){
      // Compatibility fallback for older schemas.
      let fallback=supabaseClient.from('profiles').select('*').neq('id',state.user.id);
      if(q)fallback=fallback.or(`name.ilike.%${q}%,full_name.ilike.%${q}%`);
      if(loc)fallback=fallback.ilike('location',`%${loc}%`);
      ({data,error}=await fallback.limit(50));
    }
    if(error)throw error;
    const rows=(data||[]).map(normalizeProfileRow);
    results.className='';
    results.innerHTML=rows.map(x=>`<div class="result"><span class="avatar">${x.photo?`<img src="${esc(x.photo)}">`:initials(x.name)}</span><div><b>${esc(x.name)}</b><div>${esc(x.skill)}</div><small>${esc(x.location)}</small></div><button onclick='viewOther(${JSON.stringify(x).replace(/</g,'\\u003c')})'>Profile</button></div>`).join('')||'<div class="empty">No matching profiles found. Check the spelling or try a skill/location.</div>';
  }catch(e){
    results.className='empty';
    results.textContent=friendlySupabaseError(e);
  }
}
function profile(u,other){
  const posts=state.posts.filter(p=>p.user_id===u.id);return `<div class="profile"><div class="cover">${u.cover?`<img src="${esc(u.cover)}">`:''}</div><div class="profilePhoto">${u.photo?`<img src="${esc(u.photo)}">`:initials(u.name)}</div><h2>${esc(u.name)}</h2><b>${esc(u.skill||'FIX member')}</b><p>${esc(u.bio||'')}</p><p class="muted">📍 ${esc(u.location||'')}</p><div class="stats"><span><b>${u.posts||posts.length||0}</b>Posts</span><span><b>${u.followers||0}</b>Followers</span><span><b>${u.connections||0}</b>Connections</span></div>${other?`<div class="profileActions"><button onclick="openThread('${esc(u.id)}','${esc(u.name)}')">Message</button><button class="soft" onclick="followUser('${esc(u.id)}','${esc(u.name)}')">${u.isFollowing?'Following · Unfollow':'Follow'}</button><button class="soft" onclick="connectUser('${esc(u.name)}')">Connect</button></div>`:`<div class="toolRow"><button onclick="editProfile()">Edit Profile</button><button onclick="choosePhoto('photo')">Profile Photo</button><button onclick="choosePhoto('cover')">Cover Photo</button><button onclick="render('settings')">Settings</button></div>`}<hr><h3>Posts</h3>${posts.length?posts.map(postHTML).join(''):'<div class="empty">No public posts yet.</div>'}</div>`;
}

async function loadThreads(){
  await ensureFreshSession();
  const {data,error}=await supabaseClient.from('messages').select('*')
    .or(`sender_id.eq.${state.user.id},receiver_id.eq.${state.user.id}`)
    .order('created_at',{ascending:true});
  if(error)throw error;
  const ids=[...new Set((data||[]).map(m=>m.sender_id===state.user.id?m.receiver_id:m.sender_id).filter(Boolean))];
  let pm={};
  if(ids.length){
    const rr=await supabaseClient.from('profiles').select('*').in('id',ids);
    if(!rr.error)(rr.data||[]).forEach(x=>pm[x.id]=normalizeProfileRow(x));
  }
  const groups={};
  (data||[]).forEach(m=>{
    const other=m.sender_id===state.user.id?m.receiver_id:m.sender_id;
    if(!groups[other])groups[other]={id:other,name:pm[other]?.name||'FIX member',items:[]};
    groups[other].items.push({id:m.id,text:m.content||m.text||'',mine:m.sender_id===state.user.id});
  });
  return Object.values(groups);
}
function messages(){const box='messageList';setTimeout(async()=>{try{const rows=await loadThreads(),el=$('#'+box);if(!el)return;el.className='';el.innerHTML=rows.length?rows.map(t=>`<div class="result" onclick="openThread('${esc(t.id)}','${esc(t.name)}')"><button class="avatar profileAvatarButton" onclick="event.stopPropagation();openProfileById('${esc(t.id)}')" title="View profile">${initials(t.name)}</button><div><b class="clickableIdentity" onclick="event.stopPropagation();openProfileById('${esc(t.id)}')">${esc(t.name)}</b><div class="muted">${esc(t.items.at(-1)?.text||'Start a conversation')}</div></div></div>`).join(''):'<div class="empty">No messages yet. Open a profile and tap Message.</div>';}catch(e){const el=$('#'+box);if(el)el.textContent=friendlySupabaseError(e);}},0);return `<div class="settings"><h2>Messages</h2><div id="${box}" class="empty">Loading messages…</div></div>`;}
async function openThread(userId,name){
  activeThreadUserId=userId;
  activeThreadName=name||'FIX member';
  $('#modalBody').innerHTML=`<h2>Messages</h2><b>${esc(activeThreadName)}</b><div id="threadBody" class="thread">Loading…</div><div class="messageComposer"><textarea id="reply" rows="2" placeholder="Type a message..."></textarea><button onclick="sendMessage()">Send</button></div>`;
  $('#modal').hidden=false;
  try{
    await ensureFreshSession();
    const {data,error}=await supabaseClient.from('messages').select('*')
      .or(`and(sender_id.eq.${state.user.id},receiver_id.eq.${userId}),and(sender_id.eq.${userId},receiver_id.eq.${state.user.id})`)
      .order('created_at',{ascending:true});
    if(error)throw error;
    $('#threadBody').innerHTML=(data||[]).map(m=>`<div class="bubble ${m.sender_id===state.user.id?'mine':''}">${esc(m.content||m.text||'')}</div>`).join('')||'<p class="muted">Start the conversation.</p>';
  }catch(e){$('#threadBody').textContent=friendlySupabaseError(e);}
}
async function sendMessage(){
  const text=$('#reply')?.value.trim();
  if(!text||!activeThreadUserId)return;
  try{
    await ensureFreshSession();
    const {error}=await supabaseClient.from('messages').insert({
      sender_id:state.user.id,
      receiver_id:activeThreadUserId,
      content:text
    });
    if(error)throw error;
    await openThread(activeThreadUserId,activeThreadName);
  }catch(e){alert(friendlySupabaseError(e));}
}
async function loadNotifications(){
  try{
    await ensureFreshSession();
    const {data,error}=await supabaseClient.from('notifications').select('*')
      .eq('user_id',state.user.id).order('created_at',{ascending:false}).limit(50);
    if(error)throw error;
    const rows=data||[], ids=[...new Set(rows.map(n=>n.related_user_id).filter(Boolean))];
    let names={};
    if(ids.length){
      const rr=await supabaseClient.from('profiles').select('id,name,full_name').in('id',ids);
      if(!rr.error)(rr.data||[]).forEach(x=>names[x.id]=x.full_name||x.name||'Someone');
    }
    state.notifications=rows.map(n=>({
      ...n,
      actor_id:n.related_user_id,
      actor_name:n.actor_name||names[n.related_user_id]||'Someone'
    }));
    state.unread=state.notifications.filter(n=>!(n.read||n.is_read)).length;
    save();badges();return state.notifications;
  }catch(e){console.warn('Notifications:',e);return state.notifications||[];}
}
function notificationText(n){const who=n.actor_name||'Someone';if(n.type==='post_like')return `${who} liked your post.`;if(n.type==='comment')return `${who} commented on your post.`;if(n.type==='comment_like')return `${who} liked your comment.`;if(n.type==='message')return `${who} sent you a message.`;return n.message||`${who} interacted with you.`;}
async function notifications(){
  const rows=await loadNotifications();
  const html=rows.length?rows.map(n=>`<div class="result ${n.read||n.is_read?'readNotification':'unreadNotification'}" onclick="markNotification('${n.id}')"><span class="avatar">${initials(n.actor_name||'U')}</span><div><b>${esc(notificationText(n))}</b><div class="muted">${n.created_at?new Date(n.created_at).toLocaleString():''}</div></div></div>`).join(''):'<div class="empty">No notifications yet.</div>';
  $('#main').innerHTML=`<div class="settings"><h2>Notifications</h2>${html}</div>`;
  // Opening the notification centre marks the currently displayed notifications as read.
  const unreadIds=rows.filter(n=>!(n.read||n.is_read)).map(n=>n.id);
  if(unreadIds.length){
    await supabaseClient.from('notifications').update({read:true,is_read:true}).eq('user_id',state.user.id).in('id',unreadIds);
    rows.forEach(n=>{if(unreadIds.includes(n.id)){n.read=true;n.is_read=true;}});
    state.unread=0;save();badges();
  }
  return html;
}
async function startRealtime(){
  try{
    await ensureFreshSession();
    if(realtimeChannel) await supabaseClient.removeChannel(realtimeChannel);
    realtimeChannel=supabaseClient.channel(`fixit-live-${state.user.id}`)
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:`user_id=eq.${state.user.id}`},async payload=>{
        state.unread=Number(state.unread||0)+1;save();badges();
        await loadNotifications();
      })
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:`receiver_id=eq.${state.user.id}`},async payload=>{
        state.unread=Number(state.unread||0)+1;save();badges();
        // Keep the message list fresh when the user is looking at it.
        if(document.querySelector('#messageList')) messages();
      })
      .subscribe((status,err)=>{ if(status==='CHANNEL_ERROR'||status==='TIMED_OUT') console.warn('FIX realtime:',status,err||''); });
  }catch(e){console.warn('Realtime setup:',e);}
}
async function markNotification(id){
  try{
    await supabaseClient.from('notifications').update({read:true,is_read:true}).eq('id',id).eq('user_id',state.user.id);
  }catch(e){}
  await loadNotifications();
  await notifications();
}

async function openApp(){ $('#landing').hidden=true;$('#auth').hidden=true;$('#app').hidden=false;render('home');await loadRemotePosts();await loadNotifications();badges();render('home');startRealtime(); }
$('#msgBtn').onclick=()=>render('notifications');

/* Header icon: notification bell instead of the old message envelope. */
const topNotify=$('#msgBtn');if(topNotify){topNotify.innerHTML='🔔<b id="msgBadge" hidden>0</b>';topNotify.setAttribute('aria-label','Notifications');topNotify.title='Notifications';}

function render(page){const m=$('#main');if(page==='home')m.innerHTML=home();else if(page==='search')m.innerHTML=search();else if(page==='profile')m.innerHTML=profile(state.user,false);else if(page==='settings')m.innerHTML=settings();else if(page==='rewards')m.innerHTML=rewards();else if(page==='messages')m.innerHTML=messages();else if(page==='notifications')notifications();badges();$$('nav [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));window.scrollTo(0,0);}

/* ================= END FINAL CONNECTION BUILD ================= */

/* ================= FIX AUTH/UI WIRING REPAIR =================
   The previous build contained the auth markup but did not bind the
   Create account / Log in tabs and auth buttons. This block wires them
   without changing the approved UI.
*/
(function wireFixItAuth(){
  function setAuthMessage(id,msg,isError=false){
    const el=$(id); if(!el)return; el.textContent=msg||''; el.style.color=isError?'#c00':'';
  }

  function showSignup(){
    const s=$('#signupPanel'), l=$('#loginPanel');
    if(s)s.hidden=false; if(l)l.hidden=true;
    $('#signupTab')?.classList.add('active'); $('#loginTab')?.classList.remove('active');
    setAuthMessage('#loginMsg','');
  }
  function showLogin(){
    const s=$('#signupPanel'), l=$('#loginPanel');
    if(s)s.hidden=true; if(l)l.hidden=false;
    $('#loginTab')?.classList.add('active'); $('#signupTab')?.classList.remove('active');
    setAuthMessage('#loginMsg','');
  }

  async function doLogin(){
    const email=$('#liEmail')?.value.trim(), password=$('#liPassword')?.value||'';
    if(!email||!password){setAuthMessage('#loginMsg','Enter your email and password.',true);return;}
    const btn=$('#loginBtn'); if(btn){btn.disabled=true;btn.textContent='Logging in…';}
    setAuthMessage('#loginMsg','');
    try{
      const {data,error}=await supabaseClient.auth.signInWithPassword({email,password});
      if(error)throw error;
      if(!data?.user)throw new Error('Login did not return a user.');
      await loadSupabaseUser();
      openApp();
    }catch(e){
      setAuthMessage('#loginMsg',friendlySupabaseError(e),true);
    }finally{
      if(btn){btn.disabled=false;btn.textContent='Log in';}
    }
  }

  async function doSignup(){
    const name=$('#suName')?.value.trim(), skill=$('#suSkill')?.value.trim(), location=$('#suLocation')?.value.trim();
    const email=$('#suEmail')?.value.trim(), password=$('#suPassword')?.value||'';
    if(!name||!location||!email||!password){alert('Please enter your full name, location, email and password.');return;}
    if(password.length<6){alert('Password must be at least 6 characters.');return;}
    const btn=$('#sendCode'); if(btn){btn.disabled=true;btn.textContent='Creating account…';}
    try{
      const {data,error}=await supabaseClient.auth.signUp({
        email,password,
        options:{emailRedirectTo:AUTH_REDIRECT_URL,data:{full_name:name,name,skill,location}}
      });
      if(error)throw error;
      if(data?.user && data?.session){
        const profile={id:data.user.id,full_name:name,name,skill,location,email};
        const p=await supabaseClient.from('profiles').upsert(profile,{onConflict:'id'});
        if(p.error)throw p.error;
      }
      if(data?.session){
        await loadSupabaseUser(); openApp();
      }else{
        const status=$('#confirmationStatus'); if(status)status.hidden=false;
        const msg=$('#confirmationMessage'); if(msg)msg.textContent=`We’ve sent a verification email to ${email}. Open it and tap “Verify email and continue” to activate your FIX account.`;
        
      }
    }catch(e){alert(friendlySupabaseError(e));}
    finally{if(btn){btn.disabled=false;btn.textContent='Create account';}}
  }

  async function resendConfirmation(){
    const email=$('#suEmail')?.value.trim();
    if(!email){alert('Enter your email address first.');return;}
    try{
      const {error}=await supabaseClient.auth.resend({type:'signup',email,options:{emailRedirectTo:AUTH_REDIRECT_URL}});
      if(error)throw error;
      alert('Confirmation email sent. Check your inbox.');
    }catch(e){alert(friendlySupabaseError(e));}
  }

  async function forgotPassword(){
    const email=$('#liEmail')?.value.trim();
    if(!email){setAuthMessage('#loginMsg','Enter your email address first.',true);return;}
    try{
      const {error}=await supabaseClient.auth.resetPasswordForEmail(email,{redirectTo:AUTH_REDIRECT_URL});
      if(error)throw error;
      setAuthMessage('#loginMsg','Password reset email sent. Check your inbox.');
    }catch(e){setAuthMessage('#loginMsg',friendlySupabaseError(e),true);}
  }

  async function initAuth(){
    const splash=$('#splash');
    if(splash)setTimeout(()=>{splash.style.display='none';},900);
    $('#signupTab')?.addEventListener('click',showSignup);
    $('#loginTab')?.addEventListener('click',showLogin);
    $('#loginBtn')?.addEventListener('click',doLogin);
    $('#sendCode')?.addEventListener('click',doSignup);
    $('#resendEmail')?.addEventListener('click',resendConfirmation);
    $('#forgotPassword')?.addEventListener('click',forgotPassword);

    try{
      const {data}=await supabaseClient.auth.getSession();
      if(data?.session){
        await loadSupabaseUser();
        openApp();
      }else{
        showSignup();
      }
    }catch(e){
      console.warn('Auth startup:',e);
      showSignup();
    }
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initAuth,{once:true});
  else initAuth();
})();

/* ================= FIX STABILITY PATCH =================
   Restores the complete post-login UI/navigation that was accidentally
   omitted from the previous auth-only build. Uses the existing Supabase
   schema; no tables are changed here.
*/

function uploadToBucket(bucket,file,userId){
  return (async()=>{
    if(!file) throw new Error('No file selected.');
    const ext=(file.name.split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'');
    const safe=(file.name.replace(/[^a-zA-Z0-9._-]/g,'_')||'upload').slice(-80);
    const path=`${userId}/${Date.now()}_${safe}.${ext}`;
    const up=await supabaseClient.storage.from(bucket).upload(path,file,{upsert:false,contentType:file.type||undefined});
    if(up.error) throw up.error;
    const pub=supabaseClient.storage.from(bucket).getPublicUrl(path);
    return pub.data.publicUrl;
  })();
}

function home(){
  const avatar=state.user?.photo?`<img src="${esc(state.user.photo)}">`:initials(state.user?.name);
  const posts=Array.isArray(state.posts)?state.posts:[];
  return `<div class="storyRow"><button onclick="render('profile')">${avatar} My Profile</button><button onclick="render('search')">Find People</button></div>
    <div class="composer"><span class="avatar">${avatar}</span><button onclick="openPostComposer()">What's on your mind?</button></div>
    <div class="postTabs" style="display:flex;gap:8px;margin:10px 0"><button class="soft">All Posts</button><button class="soft" onclick="render('search')">Explore</button></div>
    ${posts.length?posts.map(postHTML).join(''):'<div class="post"><div class="empty">No public posts yet.</div></div>'}`;
}

function openPostComposer(){
  $('#modalBody').innerHTML=`<h2>Create Post</h2><div class="postHead"><span class="avatar">${state.user?.photo?`<img src="${esc(state.user.photo)}">`:initials(state.user?.name)}</span><div><b>${esc(state.user?.name||'FIX member')}</b><div class="muted">${esc(state.user?.location||'')}</div></div></div><textarea id="postText" rows="5" placeholder="What's on your mind?"></textarea><input id="mediaInput" type="file" accept="image/*,video/*"><button onclick="publish()" style="background:#e00000;color:#fff;width:100%;padding:13px;margin-top:8px">Post</button>`;
  $('#modal').hidden=false;
}

function settings(){
  return `<div class="settings"><h2>Settings</h2>
    <div class="settingRow"><span>Edit Profile</span><button onclick="editProfile()">›</button></div>
    <div class="settingRow"><span>Notifications</span><button onclick="render('notifications')">›</button></div>
    <div class="settingRow"><span>Balance & Earnings</span><button onclick="render('rewards')">›</button></div>
    <div class="settingRow"><span>Account</span><button onclick="alert('Your account is connected to Supabase.')">›</button></div>
    <button onclick="logoutFixIt()" style="background:#e00000;color:#fff;width:100%;padding:13px;margin-top:18px">Log out</button>
  </div>`;
}

function rewards(){
  return `<div class="reward"><h2>Balance & Earnings</h2><div class="balance"><span>Your Balance</span><strong>$${Number(state.balance||0).toFixed(2)}</strong><span>Available Balance</span></div><h3>Earn More Rewards</h3><div class="rewardItem"><div class="desc"><b>Complete Surveys</b><div class="muted">Survey opportunities may be added through a trusted partner.</div></div><button onclick="document.getElementById('rewardNotice').hidden=false">Details</button></div><div id="rewardNotice" class="inlineNotice" hidden>No rewards provider is connected yet. This section will become active only after a legitimate partner is integrated.</div><button class="withdrawBtn" disabled title="Withdrawals are not enabled yet">Withdraw · Not available yet</button><p class="muted">FIX does not currently offer paid ad-watching rewards or withdrawals.</p></div>`;
}

function editProfile(){
  const u=state.user||{};
  $('#modalBody').innerHTML=`<h2>Edit Profile</h2><input id="epName" value="${esc(u.name||'')}" placeholder="Full name"><input id="epSkill" value="${esc(u.skill||'')}" placeholder="What do you do?"><input id="epLocation" value="${esc(u.location||'')}" placeholder="Location"><textarea id="epBio" rows="4" placeholder="Bio">${esc(u.bio||'')}</textarea><button onclick="saveProfileEdits()" style="background:#e00000;color:#fff;width:100%;padding:13px">Save changes</button>`;
  $('#modal').hidden=false;
  setTimeout(()=>attachLocationAutocomplete('epLocation','epLocationSuggestions'),0);
}
async function saveProfileEdits(){
  try{
    await ensureFreshSession();
    const name=$('#epName').value.trim(),skill=$('#epSkill').value.trim(),location=$('#epLocation').value.trim(),bio=$('#epBio').value.trim();
    const r=await supabaseClient.from('profiles').upsert({id:state.user.id,name,full_name:name,skill,location,bio,updated_at:new Date().toISOString()},{onConflict:'id'});
    if(r.error)throw r.error;
    Object.assign(state.user,{name,skill,location,bio});save();$('#modal').hidden=true;render('profile');
  }catch(e){alert(friendlySupabaseError(e));}
}

function connectUser(name){alert(`Connection request for ${name} will be connected in the next social-graph pass.`);}

async function logoutFixIt(){
  try{await supabaseClient.auth.signOut({scope:'local'});}catch(e){}
  state.user=null;state.posts=[];state.messages=[];save();location.reload();
}

/* Navigation and controls */
(function wireFixItApp(){
  function bind(){
    $$('nav button[data-page]').forEach(btn=>{
      btn.onclick=()=>render(btn.dataset.page);
    });
    $('#postBtn')?.addEventListener('click',openPostComposer);
    $('#searchBtn')?.addEventListener('click',()=>render('search'));
    $('#menuBtn')?.addEventListener('click',()=>{$('#drawer').hidden=false;});
    $('#closeDrawer')?.addEventListener('click',()=>{$('#drawer').hidden=true;});
    $('#closeModal')?.addEventListener('click',()=>{$('#modal').hidden=true;});
    $('#drawer')?.addEventListener('click',e=>{if(e.target.id==='drawer')$('#drawer').hidden=true;});
    $$('#drawer [data-page]').forEach(btn=>btn.addEventListener('click',()=>{$('#drawer').hidden=true;render(btn.dataset.page);}));
    $('#logout')?.addEventListener('click',logoutFixIt);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind,{once:true});else bind();
})();


/* ================= FIX BRAND + SOCIAL GRAPH FINAL PATCH ================= */
function badges(){
  const notificationCount=Number(state.unread||0);
  const messageCount=Number(state.unreadMessages||0);
  const paint=(el,count,label)=>{if(!el)return;el.textContent=count>99?'99+':String(count);el.hidden=count<=0;el.setAttribute('aria-label',count?`${count} unread ${label}${count===1?'':'s'}`:'');};
  paint($('#msgBadge'),notificationCount,'notification');
  paint($('#navBadge'),messageCount,'message');
}
async function loadUnreadMessages(){
  try{
    await ensureFreshSession();
    const r=await supabaseClient.from('messages').select('id',{count:'exact',head:true}).eq('receiver_id',state.user.id).is('read_at',null);
    if(r.error)throw r.error;
    state.unreadMessages=Number(r.count||0);save();badges();
  }catch(e){console.warn('Unread messages:',e);}
}
async function openApp(){
  $('#landing').hidden=true;$('#auth').hidden=true;$('#app').hidden=false;
  render('home');
  await loadRemotePosts();
  await loadNotifications();
  await loadUnreadMessages();
  badges();render('home');startRealtime();
}
async function openProfileById(userId){
  if(!userId){alert('This profile is not available for this item.');return;}
  if(userId===state.user?.id){render('profile');return;}
  try{
    await ensureFreshSession();
    const {data,error}=await supabaseClient.from('profiles').select('*').eq('id',userId).maybeSingle();
    if(error)throw error;
    if(!data){alert('This profile is not available.');return;}
    await viewOther(normalizeProfileRow(data));
  }catch(e){alert(friendlySupabaseError(e));}
}

async function viewOther(u){
  const normalized={...u};
  if(!u?.id){alert('This profile could not be opened.');return;}
  $('#main').innerHTML='<div class="empty">Loading profile…</div>';
  try{
    const [postsResult,followersResult,followingCountResult,followingResult]=await Promise.all([
      loadPostsForUser(u.id),
      supabaseClient.from('follows').select('id',{count:'exact',head:true}).eq('following_id',u.id),
      supabaseClient.from('follows').select('id',{count:'exact',head:true}).eq('follower_id',u.id),
      supabaseClient.from('follows').select('id').eq('follower_id',state.user.id).eq('following_id',u.id).maybeSingle()
    ]);
    if(postsResult.length){postsResult.forEach(p=>{p.name=normalized.name;p.location=normalized.location;p.photo=normalized.photo;});state.posts=state.posts.filter(p=>p.user_id!==u.id).concat(postsResult);}
    if(followersResult.error)throw followersResult.error;
    if(followingResult.error && !/0 rows/i.test(followingResult.error.message||''))throw followingResult.error;
    normalized.followers=Number(followersResult.count||0);
    normalized.following=Number(followingCountResult.count||0);
    normalized.isFollowing=!!followingResult.data;
  }catch(e){console.warn('Profile/follow status:',e);}
  $('#main').innerHTML=profile(normalized,true);window.scrollTo(0,0);
}
function profile(u,other){
  const posts=state.posts.filter(p=>p.user_id&&u.id&&p.user_id===u.id);
  const verified=!!(u.is_verified||u.verified||u.verification_badge);
  const actions=other?`<div class="profileActions"><button onclick="openThread('${esc(u.id)}','${esc(u.name)}')">Message</button><button class="soft" onclick="followUser('${esc(u.id)}','${esc(u.name)}')">${u.isFollowing?'Following · Unfollow':'Follow'}</button></div>`:`<div class="toolRow"><button onclick="editProfile()">Edit Profile</button><button onclick="choosePhoto('photo')">Profile Photo</button><button onclick="choosePhoto('cover')">Cover Photo</button><button onclick="render('settings')">Settings</button><button class="verifiedAction" onclick="showVerificationInfo()">${verified?'✓ Verified':'Get verified ✓'}</button></div>`;
  const profession=u.skill?`<div class="profileProfession">${esc(u.skill)}</div>`:'';
  const location=u.location?`<p class="profileLocation"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 21s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12Z" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="9" r="2.4" stroke="currentColor" stroke-width="2"/></svg><span>${esc(u.location)}</span></p>`:'';
  return `<div class="profile"><div class="cover">${u.cover?`<img src="${esc(u.cover)}">`:''}</div><div class="profilePhoto">${u.photo?`<img src="${esc(u.photo)}">`:initials(u.name)}</div><div class="profileNameLine"><h2 style="margin:0">${esc(u.name||'')}</h2>${verified?'<span class="verificationTick" title="Verified profile" aria-label="Verified profile">✓</span>':''}</div>${location}${profession}<div class="stats"><span><b>${Number(u.followers||0)}</b>Followers</span><span><b>${Number(u.following||0)}</b>Following</span></div>${actions}<hr><h3>Posts</h3>${posts.length?posts.map(postHTML).join(''):'<div class="empty">No public posts yet.</div>'}</div>`;
}
async function followUser(userId,displayName='this member'){
  if(!state.user?.id){alert('Please log in to follow people.');return;}
  if(!userId||userId===state.user.id){alert('You cannot follow your own profile.');return;}
  try{
    await ensureFreshSession();
    const current=await supabaseClient.from('follows').select('id').eq('follower_id',state.user.id).eq('following_id',userId).maybeSingle();
    if(current.error && !/0 rows/i.test(current.error.message||''))throw current.error;
    if(current.data){
      const removed=await supabaseClient.from('follows').delete().eq('id',current.data.id).eq('follower_id',state.user.id);
      if(removed.error)throw removed.error;
      console.info(`You unfollowed ${displayName}.`);
    }else{
      const added=await supabaseClient.from('follows').insert({follower_id:state.user.id,following_id:userId});
      if(added.error)throw added.error;
      console.info(`You are now following ${displayName}.`);
    }
    await loadNotifications();
    const target=await supabaseClient.from('profiles').select('*').eq('id',userId).maybeSingle();
    if(target.error)throw target.error;
    await viewOther(normalizeProfileRow(target.data||{id:userId,name:displayName}));
  }catch(e){alert(friendlySupabaseError(e));}
}
async function startRealtime(){
  try{
    await ensureFreshSession();
    if(realtimeChannel)await supabaseClient.removeChannel(realtimeChannel);
    realtimeChannel=supabaseClient.channel(`fix-live-${state.user.id}`)
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:`user_id=eq.${state.user.id}`},async()=>{await loadNotifications();badges();})
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:`receiver_id=eq.${state.user.id}`},async()=>{await loadUnreadMessages();if(document.querySelector('#messageList'))messages();})
      .on('postgres_changes',{event:'UPDATE',schema:'public',table:'messages',filter:`receiver_id=eq.${state.user.id}`},loadUnreadMessages)
      .subscribe((status,err)=>{if(status==='CHANNEL_ERROR'||status==='TIMED_OUT')console.warn('FIX realtime:',status,err||'');});
  }catch(e){console.warn('Realtime setup:',e);}
}

function home(){
 const avatar=state.user?.photo?`<img src="${esc(state.user.photo)}">`:initials(state.user?.name);
 const posts=Array.isArray(state.posts)?state.posts:[];
 const cards=posts.map((p,i)=>`${postHTML(p)}${(i+1)%3===0?'<div class="sponsoredInline"><b>Sponsored · In-feed ad slot</b><div>Reserved for an approved advertising provider. No ad is served until configured.</div></div>':''}`).join('');
 return `<div class="storyRow"><button onclick="render('profile')">${avatar} My Profile</button><button onclick="render('search')">Find People</button></div><div class="composer"><span class="avatar">${avatar}</span><button onclick="openPostComposer()">What’s on your mind?</button></div><div class="postTabs" style="display:flex;gap:8px;margin:10px 0"><button class="soft">All Posts</button><button class="soft" onclick="render('search')">Explore</button></div>${cards||'<div class="post"><div class="empty">No public posts yet.</div></div>'}`;
}

/* FINAL UX PATCH: read-state, follow notifications, and future settings placeholders. */
function notificationText(n){
  const who=n.actor_name||'Someone';
  if(n.type==='post_like')return `${who} liked your post.`;
  if(n.type==='comment')return `${who} commented on your post.`;
  if(n.type==='comment_like')return `${who} liked your comment.`;
  if(n.type==='message')return `${who} sent you a message.`;
  if(n.type==='follow')return `${who} started following you.`;
  return n.message?`${who} ${n.message}.`:`${who} interacted with you.`;
}
async function openThread(userId,name){
  activeThreadUserId=userId;activeThreadName=name||'FIX member';
  let peer={id:userId,name:activeThreadName};
  try{const pr=await supabaseClient.from('profiles').select('*').eq('id',userId).maybeSingle();if(!pr.error&&pr.data)peer=normalizeProfileRow(pr.data);}catch(e){console.warn('Chat profile lookup:',e);}
  $('#modalBody').innerHTML=`<div class="chatProfileHeader"><button class="chatIdentity" onclick="openProfileById('${esc(userId)}')" title="View profile"><span class="avatar">${peer.photo?`<img src="${esc(peer.photo)}">`:initials(peer.name)}</span><span><b>${esc(peer.name)}</b><small>View profile</small></span></button><button class="close" onclick="$('#modal').hidden=true">×</button></div><div id="threadBody" class="thread">Loading…</div><div class="messageComposer"><textarea id="reply" rows="2" placeholder="Type a message..."></textarea><button onclick="sendMessage()">Send</button></div>`;
  $('#modal').hidden=false;
  try{
    await ensureFreshSession();
    await supabaseClient.from('messages').update({read_at:new Date().toISOString()}).eq('receiver_id',state.user.id).eq('sender_id',userId).is('read_at',null);
    const {data,error}=await supabaseClient.from('messages').select('*').or(`and(sender_id.eq.${state.user.id},receiver_id.eq.${userId}),and(sender_id.eq.${userId},receiver_id.eq.${state.user.id})`).order('created_at',{ascending:true});
    if(error)throw error;
    $('#threadBody').innerHTML=(data||[]).map(m=>`<div class="bubble ${m.sender_id===state.user.id?'mine':''}">${esc(m.content||m.text||'')}</div>`).join('')||'<p class="muted">Start the conversation.</p>';
    await loadUnreadMessages();
  }catch(e){const tb=$('#threadBody');if(tb)tb.textContent=friendlySupabaseError(e);}
}
function settings(){
 return `<div class="settings"><h2>Settings</h2>
 <div class="settingRow"><span>Edit Profile</span><button onclick="editProfile()">›</button></div>
 <div class="settingRow"><span>Notifications</span><button onclick="render('notifications')">›</button></div>
 <div class="settingRow"><span>Balance & Earnings</span><button onclick="render('rewards')">›</button></div>
 <div class="settingRow"><span>Appearance <small class="muted" style="display:block;margin-top:4px">${document.body.classList.contains('night-mode')?'Night mode · black and red':'Day mode · white and red'}</small></span><button onclick="toggleTheme()">${document.body.classList.contains('night-mode')?'Switch to Day ☀':'Switch to Night ☾'}</button></div>
 <div class="settingRow"><span>Verification information</span><button onclick="showVerificationInfo()">›</button></div>
 <div class="settingRow"><span>Account</span><button onclick="alert('Your account is connected to Supabase.')">›</button></div>
 <button onclick="logoutFixIt()" style="background:#e00000;color:#fff;width:100%;padding:13px;margin-top:18px">Log out</button></div>`;
}

async function render(page){
 const m=$('#main');
 if(page==='home')m.innerHTML=home();
 else if(page==='search')m.innerHTML=search();
 else if(page==='profile'){
   m.innerHTML=profile(state.user,false);
   try{
     const [r,f]=await Promise.all([
       supabaseClient.from('follows').select('id',{count:'exact',head:true}).eq('following_id',state.user.id),
       supabaseClient.from('follows').select('id',{count:'exact',head:true}).eq('follower_id',state.user.id)
     ]);
     if(!r.error)state.user.followers=Number(r.count||0);
     if(!f.error)state.user.following=Number(f.count||0);
     save();m.innerHTML=profile(state.user,false);
   }catch(e){console.warn('Follower count:',e);}
 }
 else if(page==='settings')m.innerHTML=settings();
 else if(page==='rewards')m.innerHTML=rewards();
 else if(page==='messages')m.innerHTML=messages();
 else if(page==='notifications')await notifications();
 badges();$$('nav [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));window.scrollTo(0,0);
}


function showVerificationInfo(){
  $('#modalBody').innerHTML=`<h2>Verification badge</h2><p>A verification badge is the check mark shown beside a profile name on social platforms. It helps people distinguish an authenticated, notable or otherwise eligible account from impersonators.</p><p>FIX should introduce a clear review process before issuing badges: confirm control of the account, review impersonation risk, and explain eligibility. A badge must not be sold as a guarantee that a person is safe or honest.</p><p class="muted">Badge applications and reviews are not connected yet. FIX does not collect payment-card details here.</p><button onclick="$('#modal').hidden=true" style="background:#e00000;color:#fff;width:100%;padding:12px">Understood</button>`;
  $('#modal').hidden=false;
}

/* Worldwide location autocomplete: suggestions are based on typed text only; FIX does not request device GPS. */
function attachLocationAutocomplete(inputId, listId){
  const input=document.getElementById(inputId); if(!input)return;
  let list=document.getElementById(listId);
  if(!list){list=document.createElement('div');list.id=listId;list.className='locationSuggestions';list.hidden=true;input.insertAdjacentElement('afterend',list);}
  let timer=null, lastQuery='';
  input.setAttribute('autocomplete','off');
  input.addEventListener('input',()=>{
    const q=input.value.trim();clearTimeout(timer);
    if(q.length<2){list.hidden=true;list.innerHTML='';return;}
    timer=setTimeout(async()=>{
      if(q===lastQuery)return;lastQuery=q;
      list.hidden=false;list.innerHTML='<div class="locationSuggestion muted">Finding matching places…</div>';
      try{
        const url='https://photon.komoot.io/api/?limit=7&q='+encodeURIComponent(q);
        const response=await fetch(url,{headers:{'Accept':'application/json'}});if(!response.ok)throw new Error('Location lookup unavailable');
        const json=await response.json();const features=json.features||[];
        list.innerHTML=features.length?features.map((f,i)=>{const p=f.properties||{};const label=[p.name,p.district,p.city,p.state,p.country].filter((v,i,a)=>v&&a.indexOf(v)===i).join(', ');return `<button type="button" class="locationSuggestion" data-index="${i}">${esc(label||q)}</button>`}).join(''):'<div class="locationSuggestion muted">No matches found. You can keep your location as typed.</div>';
        [...list.querySelectorAll('button[data-index]')].forEach((button,i)=>button.addEventListener('click',()=>{const p=features[i].properties||{};input.value=[p.name,p.district,p.city,p.state,p.country].filter((v,i,a)=>v&&a.indexOf(v)===i).join(', ');list.hidden=true;list.innerHTML='';input.dispatchEvent(new Event('change',{bubbles:true}));}));
      }catch(e){list.innerHTML='<div class="locationSuggestion muted">Suggestions are temporarily unavailable. You can type your location manually.</div>';}
    },450);
  });
  document.addEventListener('click',e=>{if(e.target!==input&&!list.contains(e.target))list.hidden=true;});
}
function setupLocationAutocomplete(){
  attachLocationAutocomplete('suLocation','suLocationSuggestions');
  attachLocationAutocomplete('epLocation','epLocationSuggestions');
  attachLocationAutocomplete('locQ','locQSuggestions');
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setupLocationAutocomplete,{once:true});else setupLocationAutocomplete();
